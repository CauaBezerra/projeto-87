import React, { Component } from "react";
import {
  View,
  SafeAreaView,
  Image,
  TextInput,
  Alert,
  TouchableOpacity,
  Text
} from "react-native";

const appIcon = require("../assets/logo.png");

export default class LoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      fontsLoaded: false,
      userSignedIn: false
    };
  }

  signIn = async (email, password) => {
    firebase.auth()
    .signInWithEmailAndPassword(email, password)
    .then(() => {
      this.props.navigation.replace("dashboard");
    })
    .catch(error => {
      Alert.alert(error.message);
    })
  };


  render() {

    return (
        <View style={styles.container}>
          <SafeAreaView style={styles.droidSafeArea} />

          <Text style={styles.appTitleText}>Epectagrama</Text>
          <Image source={appIcon} style={styles.appIcon} />

          <TextInput
            style={styles.textinput}
            onChangeText={text => this.setState({ email: text })}
            placeholder={"Digite o e-mail"}
            placeholderTextColor={"#FFFFFF"}
            autoFocus
          />
          <TextInput
            style={[styles.textinput, { marginTop: 20 }]}
            onChangeText={text => this.setState({ password: text })}
            placeholder={"Digite a senha"}
            placeholderTextColor={"#FFFFFF"}
            secureTextEntry
          />
          <TouchableOpacity
            style={[styles.button, { marginTop: 20 }]}
            onPress = {() => this.signIn(email, password)}
          >
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>
          <TouchableOpacity 
          onPress = {() => this.props.navigation.navigate("registro")}>
            <Text style = {styles.buttonTextNewUser}> fazer registro </Text>
          </TouchableOpacity>
        </View>
      );
    }
}